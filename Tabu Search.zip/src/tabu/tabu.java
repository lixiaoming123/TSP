package tabu;

import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.tools.Diagnostic;

import org.junit.Test;

import sun.java2d.loops.DrawLine;

public class tabu {
	private   int length=20 ;  //���ɳ���
	private  int[][] taboo=new int[20][31];
	
	public int[][] gettaboo(){
		return taboo;
	}
	//���ı��л������
   // int [] path=new int[30];
   
    public tabu(int length){
    	this.length=length;
    	
    }
     
	public List <String []> getdata(){
		String urlfrist=System.getProperty("user.dir");
		String urlend="/lib/tsp.txt";
		File file=new File(urlfrist+urlend);
		
		InputStreamReader inputStreamReader= null;
		try {
			inputStreamReader=new InputStreamReader(new FileInputStream(file));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
		
		String  data="";
	    String [] xy=new String[2];
	    List <String []> list =new ArrayList<String []>();
		try {
			
			data=bufferedReader.readLine();
			xy=data.split(" ");
		    list.add(xy);
			while(data!=null){
				data=bufferedReader.readLine();
				if(data!=null){
				xy=data.split(" ");
			    list.add(xy);}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(list==null||list.size()<0){
			return null;
		}
		else return list;
		
			}
	
	//�������г���֮��ľ���
	
	public float[][]  getdistance(){
		float x,y; //��
		List <String []> list=getdata();
		float distance[][]=new float[30][30];
		for(int i=0;i<list.size();i++){
			for(int j=0;j<list.size();j++){
				if(i==j){
					distance[i][j]=0;	
				}
				else{
					x=(float) StrictMath.pow(Integer.parseInt(list.get(i)[0])-Integer.parseInt(list.get(j)[0]), 2);
					y=(float) StrictMath.pow(Integer.parseInt(list.get(i)[1])-Integer.parseInt(list.get(j)[1]), 2);
					distance[i][j]=(float) StrictMath.pow(x+y, 0.5);
				}	
			}
		}
		return distance;
	}

	//��ʼ��·��
	public int [] init(){
			
		int [] path=new int[30];
		
		Random random=new Random();
		
		
			
		for(int i=0;i<30;i++){
			path[i]=random.nextInt(30);
			for(int j=0;j<i;j++){
				if(path[j]==path[i]){
					i--;
					break;
				}
			}	
		}	
		
		
		
	
		return path;
	}
	
	//���·������,
	public float getpathlength(int [] path){
		float pathlength=0;
		float [][] distance=getdistance();
		for(int i=0;i<29;i++){
			pathlength+=distance[path[i]][path[i+1]];	
		}
		pathlength+=distance[path[29]][path[0]] ; //������ʼ��
		
		return pathlength;
	}
	
	
	//��ʼ��Ļ�ȡ����һ�ַ���

	public void get_init(){
		List <String []> list =getdata();
		int [] minindex=new int [30];
		float [][] distance =getdistance();
		for(int i=0;i<30;i++){
			float min=Float.MAX_VALUE;
			int index = 0;
			for(int j=0;j<30;j++){
				if(i!=j){
					if(distance[i][j]<min){
						min=distance[i][j];
						index=j;
					}
				}
				
			}
			minindex[i]=index;
		}
		for(int i=0;i<30;i++){
			
			System.out.println(i+"\t"+minindex[i]+"\t"+distance[i][minindex[i]]);
		}
		}
		
	// ����·���ǲ����ڽ��ɱ���
	public int checktaboo(int [] path ){
		int flag;
		for(int i=0;i<length;i++){
			flag=1;
			for(int j=0;j<30;j++){
				if(path[j]!=taboo[i][j]){
					flag=0;
					break;
				}
			}
			if(flag==1){
				return flag;
			}
		}
		return 0;
	}	
	//���ɱ������ɾ��Ԫ��
	public void changetaboo(int [] path){
		for(int i=0;i<this.length;i++){
			if(taboo[i][30]>0){
				taboo[i][30]--;
			}
		}
		for(int i=0;i<length;i++){
			if(taboo[i][30]==0){
				for(int j=0;j<30;j++){
					taboo[i][j]=path[j];
					taboo[i][30]=length;
				}
				break;
			}
		}
	}
	
	public void copy(int [] temp,int [] path){
		if(temp.length!=path.length){
			System.out.println("���Ȳ�ƥ���޷�����");
			return;
		}
		for(int i=0;i<temp.length;i++){
			temp[i]=path[i];
		}
		
	}
	public void print(int[]path){
		for(int i=0;i<path.length;i++){
			System.out.print(path[i]+"->");
		}
		System.out.println(path[0]);
	}
	public static void main(String[] args) {
		int [] path=new int[30];
		for(int i=0;i<30;i++){
			path[i]=i;
		}
		float [] minvalue=new float[20]; 
		
		
		int [] best=new int[30];
		tabu tabu=new tabu(20);
		//���ѡ��һ��·����Ϊ��ǰ����·������ʼ�㷨
		for(int q=0;q<1;q++){
		tabu.copy(best, tabu.init());
		
		//tabu.copy(best, path);
		int [] curr=new int[30];
		tabu.copy(curr, best);
		int []  temp=new int[30];
		float min;
		float min0=tabu.getpathlength(curr);
		 int [] minpath=new int[30];
	    long t1=System.currentTimeMillis();
	    int count=0;
	    int temp0;
	   
	    
	    for(long  i=0;i<2000;i++){
	    	tabu.changetaboo(curr);
	    	  min=Float.MAX_VALUE;
	    	 if(tabu.getpathlength(curr)<min0){
					min0=tabu.getpathlength(curr);
					tabu.copy(minpath,curr);
					}
	    	for(int j=0;j<30;j++){
	    		for(int k=j+1;k<30;k++){
	    			tabu.copy(best, curr);
	    			temp0=best[j];
	    			best[j]=best[k];
	    			best[k]=temp0;
	    		if(tabu.checktaboo(best)==1){
	    			//	System.out.println("����");
	    				continue;
	    			}
	    			//for(int m=0;m<30;m++){
	    		//		System.out.print(best[m]+"\t");
	    			//}
	    			if(tabu.getpathlength(best)<min){
	    				min=tabu.getpathlength(best);
	    				tabu.copy(temp, best);		
	    				}
	    			}
	    		//	System.out.println();	
	    		}
	    	/* for(int j=0;j<100;j++){
		    	
		    			tabu.copy(best, curr);
		    			int k=new Random().nextInt(30);
		    			int m=new Random().nextInt(30);
		    			if(k==m){
		    				m=new Random().nextInt(30);
		    			}
		    			temp0=best[m];
		    			best[m]=best[k];
		    			best[k]=temp0;
		    		if(tabu.checktaboo(best)==1){
		    				System.out.println("�ڽ��ɱ��г���");
		    				continue;
		    			}
		    			//for(int m=0;m<30;m++){
		    		//		System.out.print(best[m]+"\t");
		    			//}
		    			if(tabu.getpathlength(best)<min){
		    				min=tabu.getpathlength(best);
		    				tabu.copy(temp, best);		
		    				}
		    			
		    		//	System.out.println();	
		    		}*/
	    	
	    	 tabu.copy(curr, temp);
	    	 System.out.print(count+++"\t"+tabu.getpathlength(curr)+"\t"+q+"\t");
	    	 tabu.print(temp);
	    /*	for(int k=0;k<50;k++){
	    		 for(int w=0;w<31;w++){
	    			// if(tabu.gettaboo()[k][30]!=0)
	    			 System.out.print(tabu.gettaboo()[k][w]+"\t");
	    		 }
	    		 System.out.println();
	    	 }*/
	    	
	    }
	   
	    
	    
	   
	   
	    System.out.print(min0+"\t");
	    tabu.print(minpath);
	    System.out.println(System.currentTimeMillis()-t1);
	    minvalue[q]=min0;
	}
	
		for(int i=0;i<minvalue.length;i++){
			System.out.print(minvalue[i]+"\n");
		}
	}
}
