package tabu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class pathlength {
	public List <String []> getdata(){
		String urlfrist=System.getProperty("user.dir");
		String urlend="/lib/tsp.txt";
		File file=new File(urlfrist+urlend);
		
		InputStreamReader inputStreamReader= null;
		try {
			inputStreamReader=new InputStreamReader(new FileInputStream(file));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
		
		String  data="";
	    String [] xy=new String[2];
	    List <String []> list =new ArrayList<String []>();
		try {
			
			data=bufferedReader.readLine();
			xy=data.split(" ");
		    list.add(xy);
			while(data!=null){
				data=bufferedReader.readLine();
				if(data!=null){
				xy=data.split(" ");
			    list.add(xy);}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(list==null||list.size()<0){
			return null;
		}
		else return list;
		
			}
	
	//�������г���֮��ľ���
	
	public float[][]  getdistance(){
		float x,y; //��
		List <String []> list=getdata();
		float distance[][]=new float[30][30];
		for(int i=0;i<list.size();i++){
			for(int j=0;j<list.size();j++){
				if(i==j){
					distance[i][j]=0;	
				}
				else{
					x=(float) StrictMath.pow(Integer.parseInt(list.get(i)[0])-Integer.parseInt(list.get(j)[0]), 2);
					y=(float) StrictMath.pow(Integer.parseInt(list.get(i)[1])-Integer.parseInt(list.get(j)[1]), 2);
					distance[i][j]=(float) StrictMath.pow(x+y, 0.5);
				}	
			}
		}
		return distance;
	}
	public static void main(String[] args) {
		pathlength dis=new pathlength();
		float [][] pat=dis.getdistance();
		int [] path=new int[30];
	    path[0]=0;
	    int temp1=0;
		int temp;
		float min=Float.MAX_VALUE;
		for(int i=0;i<29;i++){
			temp=temp1;
			min=Float.MAX_VALUE;
			for(int j=0;j<30;j++){
				System.out.print(pat[i][j]+"\t");;
				if(temp!=j){
				if(pat[temp][j]<min){
					temp1=j;
				}
			}
				}
			System.out.println();
			path[i+1]=temp1;
			for(int m=0;m<30;m++){
				pat[m][temp1]=Float.MAX_VALUE;
			}
		}
		
		for(int i=0;i<30;i++){
			System.out.print(path[i]+"->");
		}
		
		System.out.println("\n"+new tabu(50).getpathlength(path));
	}
}
