package k_means;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.Test;
public class k_means {
	/*
	 * ��ȡtxt,��txt��ȡ����
	 */
	public  List<String []> readtext(){
		String urlfrist=System.getProperty("user.dir");
		String urlend="\\lib\\lris.txt" ;
		File file=new File(urlfrist+urlend);
			
		InputStreamReader inflater = null;
		try {
			inflater = new InputStreamReader(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bufferedReader=new BufferedReader(inflater);
		String [] data=null;
		List<String[]> list=new ArrayList();
		String line="";
		try {
			line=bufferedReader.readLine();
			int count =1;
			data=line.split(",");
			list.add(0, data);
			while(line!=null){
				line=bufferedReader.readLine();
				if(line!=null){
					data=line.split(",");
					list.add(count,data);
					count++;
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}
	
	public int min_index(float[] num){
		float min=num[0];
		int index=0;
		for(int i=0;i<num.length;i++){
			if(num[i]<min){
				index=i;
				min=num[i];
			}
		}
		return index;
	}
	
	public List< Float>max_min(float[] num){
	   float max=num[2];
	   float  min=num[2];
		List <Float> list =new ArrayList<Float>();
		for(int i=0;i<num.length;i++){
			if(num[i]>max){
				max=num[i];
			}
			if(num[i]<min){
				min=num[i];
			}
			
		}
		
		   list.add(max);
		  list.add(min);
		
			return list;
		
	}
	
		/*
		 * kmeans�㷨ʵ��																																										
		 */
	@Test
	public void kmeans(){
		List<String []> list=readtext();
		int k= 3;  //�صĸ���
		int m=list.size();  //��������
		int n=list.get(0).length-1;   //����ά��
        long max=1000000;    //����������
        float[] w=new float[n];  
        List<float []>listcent0=new ArrayList<float[]>();
        List<float []>listcent1=new ArrayList<float[]>();
        List<float []>listcent2=new ArrayList<float[]>();
        int[] yy=new int[]{0,0,0};
        int count1=0;
        //��ʼ��������
       
       Random r=new Random();  //�������
   
       
       float[][] listk=new float[k][n];  //������
       
       
       float[] w1=new float[m];
       List<Float> lisFloats=new ArrayList<Float>();
       for(int a=0;a<k;a++){
       for(int i=0;i<n;i++){
    	   for(int j=0;j<m;j++){
    		 w1[j]=(Float.parseFloat(list.get(j)[i]));
    		// System.out.print(w1[i]+"\t");
    	   } 
    	  lisFloats=max_min(w1);
    
    	  DecimalFormat decimalFormat=new DecimalFormat(".00");
    	  float w2=Math.abs(r.nextFloat());
    	  
    	  w[i]=(lisFloats.get(0)-lisFloats.get(1))*w2+lisFloats.get(1);
    	  w[i]=Float.parseFloat(decimalFormat.format(w[i]));
    	  listk[a][i]=w[i];
    	  System.out.println(w[i]);
       }
            
       }
      for(int i=0;i<listk.length;i++){
    	   for(int j=0;j<n;j++){
    	   System.out.print(listk[i][j]+"\t");}
    	   System.out.println();
       }
        
       
      float[][] center0=listk; //��ʼ��������
      float[][] center1=new float[k][n];
      for(long a=0;a<max;a++){
     
   
    
    	  //����ÿ���㵽�����ĵľ���,��������ĵ�����ĵ��Ϊһ�ء�
    	  for(int i=0;i<m;i++){ 
    		  float[] sum=new float[]{0,0,0};  
    		  for(int b=0;b<k;b++){
    		 for(int j=0;j<n;j++){
    				sum[b]=(float) Math.pow(Float.parseFloat(list.get(i)[j])-listk[b][j], 2)+sum[b];
    			 }
    		       sum[b]=(float) Math.pow(sum[b], 1.0/n);
    		    // listcent.add(min_index(sum),w);
    		 } 
    		  int su=min_index(sum);
  		    for(int l=0;l<n;l++){
  		    	w[l]=Float.parseFloat(list.get(i)[l]);
  		     }
  		    if(su==0)
  		    listcent0.add(w);
  		    if(su==1){
  		    	 listcent1.add(w);
  		    }
  		   if(su==2){
  			   listcent2.add(w);
  		   }
    	  }
    	  
    	
    	  for(int j=0;j<n;j++){
    		  center1[0][j]=0;
    		  for(int i=0;i<listcent0.size();i++){
    			  center1[0][j]+= listcent0.get(i)[j];
    		  }
    		  center1[0][j]=  center1[0][j]/n;
    		  
    	  }
    	  
    	  for(int j=0;j<n;j++){
    		  center1[1][j]=0;
    		  for(int i=0;i<listcent1.size();i++){
    			  center1[1][j]+= listcent1.get(i)[j];
    		  }
    		  center1[1][j]=  center1[1][j]/n;
    		  
    	  }
    	  for(int j=0;j<n;j++){
    		  center1[2][j]=0;
    		  for(int i=2;i<listcent2.size();i++){
    			  center1[2][j]+= listcent2.get(i)[j];
    		  }
    		  center1[2][j]=  center1[2][j]/n;
    		  
    	  }    	  
    	  
    	  //�ж��Ƿ����ֹͣ����
          float cu=0;
         for(int b=0;b<k;b++){
        	 for(int i=0;i<n;i++){
        		 cu=cu+(float)(Math.pow(center1[b][i]-center0[b][i], 2));
        	 }
         }
          cu=(float) Math.pow(cu, 1.0/n);  
            if(cu<100000000){
            	for(int i=0;i<listcent0.size();i++){
            		for(int j=0;j<n;j++){
            			System.out.print(listcent0.get(i)[j]+"\t");
            		}
            		System.out.println();
            	}
            	System.out.println("\n\n\n");
            	for(int i=0;i<listcent1.size();i++){
            		for(int j=0;j<n;j++){
            			System.out.print(listcent1.get(i)[j]+"\t");
            		}
            		System.out.println();
            	}
            	System.out.println("\n\n\n");
            	for(int i=0;i<listcent2.size();i++){
            		for(int j=0;j<n;j++){
            			System.out.print(listcent2.get(i)[j]+"\t");
            		}
            		System.out.println();
            	}
            	
            	break;	  
            	}else {
            	 for(int b=0;b<k;b++){
                	 for(int i=0;i<n;i++){
                	center0[b][i]=center1[b][i]	;
                	 }
                	 }
			}
            
            System.out.println(count1);
            count1++;
      }
        
     
      
     
        
	}
}
